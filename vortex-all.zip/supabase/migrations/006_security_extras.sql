alter table public.messages add column fwd_from text check (fwd_from is null or char_length(fwd_from) <= 100);
alter table public.chats add column avatar_url text;

create table public.blocks (
  blocker_id uuid not null references public.profiles(id) on delete cascade,
  blocked_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id),
  check (blocker_id <> blocked_id)
);
alter table public.blocks enable row level security;
create policy blocks_select on public.blocks for select to authenticated using (blocker_id = auth.uid());
create policy blocks_insert on public.blocks for insert to authenticated with check (blocker_id = auth.uid());
create policy blocks_delete on public.blocks for delete to authenticated using (blocker_id = auth.uid());
grant select, insert, delete on public.blocks to authenticated;

create function public.is_blocked_between(a uuid, b uuid) returns boolean language sql security definer set search_path = public stable as $$
  select exists (select 1 from public.blocks where (blocker_id = a and blocked_id = b) or (blocker_id = b and blocked_id = a)) $$;
revoke all on function public.is_blocked_between(uuid,uuid) from public;
grant execute on function public.is_blocked_between(uuid,uuid) to authenticated;

create or replace function public.can_post(cid uuid) returns boolean language sql security definer set search_path = public stable as $$
  select exists (select 1 from public.chat_members cm join public.chats c on c.id = cm.chat_id
    where cm.chat_id = cid and cm.user_id = auth.uid() and (
      (c.type = 'direct' and not exists (select 1 from public.chat_members o
        where o.chat_id = cid and o.user_id <> auth.uid() and public.is_blocked_between(auth.uid(), o.user_id)))
      or (c.type = 'group' and (not c.only_admins_post or cm.role in ('owner','admin')))
      or (c.type = 'channel' and cm.role in ('owner','admin')))) $$;

create or replace function public.start_direct_chat(other uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); cid uuid;
begin
  if me is null then raise exception 'not authenticated'; end if;
  if other is null or other = me then raise exception 'invalid user'; end if;
  if not exists (select 1 from public.profiles where id = other) then raise exception 'user not found'; end if;
  if public.is_blocked_between(me, other) then raise exception 'blocked'; end if;
  select c.id into cid from public.chats c
    join public.chat_members a on a.chat_id = c.id and a.user_id = me
    join public.chat_members b on b.chat_id = c.id and b.user_id = other
    where c.type = 'direct' limit 1;
  if cid is null then
    insert into public.chats (type) values ('direct') returning id into cid;
    insert into public.chat_members (chat_id, user_id) values (cid, me), (cid, other);
  end if;
  return cid;
end $$;

create or replace function public.create_chat(kind text, ttl text, descr text, pub boolean, slg text) returns uuid
language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); cid uuid;
begin
  if me is null then raise exception 'not authenticated'; end if;
  if kind not in ('group','channel') then raise exception 'invalid type'; end if;
  if char_length(btrim(coalesce(ttl,''))) < 1 then raise exception 'title required'; end if;
  if kind = 'channel' and coalesce(pub,false) and slg is null then raise exception 'slug required'; end if;
  if (select count(*) from public.chats where created_by = me and created_at > now() - interval '1 hour') >= 10 then raise exception 'rate limit'; end if;
  insert into public.chats (type, title, description, is_public, slug, created_by, only_admins_post)
  values (kind, left(btrim(ttl),100), left(coalesce(descr,''),500), kind = 'channel' and coalesce(pub,false),
    case when kind = 'channel' and coalesce(pub,false) then lower(slg) else null end, me, kind = 'channel')
  returning id into cid;
  insert into public.chat_members (chat_id, user_id, role) values (cid, me, 'owner');
  return cid;
end $$;

create function public.limit_messages() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from public.messages where sender_id = new.sender_id and created_at > now() - interval '10 seconds') >= 10
     or (select count(*) from public.messages where sender_id = new.sender_id and created_at > now() - interval '1 minute') >= 40 then
    raise exception 'rate limit';
  end if;
  return new;
end $$;
create trigger messages_rate_limit before insert on public.messages for each row execute function public.limit_messages();

create function public.set_chat_avatar(cid uuid, p text) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_chat_admin(cid) then raise exception 'forbidden'; end if;
  if public.chat_type(cid) = 'direct' then raise exception 'invalid chat'; end if;
  if p is not null and p not like auth.uid()::text || '/%' then raise exception 'invalid path'; end if;
  update public.chats set avatar_url = p where id = cid;
end $$;
revoke all on function public.set_chat_avatar(uuid,text) from public;
grant execute on function public.set_chat_avatar(uuid,text) to authenticated;

create policy attachments_delete_own on public.attachments for delete to authenticated
  using (exists (select 1 from public.messages m where m.id = message_id and m.sender_id = auth.uid()));
grant delete on public.attachments to authenticated;
create policy attachments_remove on storage.objects for delete to authenticated
  using (bucket_id = 'attachments' and exists (
    select 1 from public.attachments a join public.messages m on m.id = a.message_id
    where a.path = name and m.sender_id = auth.uid()));
