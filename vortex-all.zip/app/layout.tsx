import type { Metadata, Viewport } from "next";
import "./globals.css";
import Splash from "@/components/Splash";

export const metadata: Metadata = {
  title: "VORTEX", description: "Мессенджер VORTEX", manifest: "/manifest.webmanifest",
  icons: { icon: [{ url: "/icon-192.png", sizes: "192x192", type: "image/png" }, { url: "/icon.svg", type: "image/svg+xml" }], apple: "/apple-touch-icon.png" },
  appleWebApp: { capable: true, title: "VORTEX", statusBarStyle: "black-translucent" },
  formatDetection: { telephone: false },
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, viewportFit: "cover", themeColor: "#080B09" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="ru"><body className="min-h-dvh"><Splash />{children}</body></html>;
}
