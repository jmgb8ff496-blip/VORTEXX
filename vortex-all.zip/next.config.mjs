const headers = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "microphone=(self), camera=(), geolocation=()" },
];
/** @type {import('next').NextConfig} */
export default {
  reactStrictMode: true,
  async headers() { return [{ source: "/:path*", headers }]; },
};
