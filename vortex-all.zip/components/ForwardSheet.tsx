"use client";
import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import Avatar from "./Avatar";

type Row = { id: string; name: string; avatar: string | null };
type Ch = { id: string; type: string; title: string | null; avatar_url: string | null };
type Oth = { chat_id: string; profiles: { display_name: string; avatar_url: string | null } | null };

export default function ForwardSheet({ text, from, onClose }: { text: string; from: string; onClose: () => void }) {
  const sb = createClient();
  const [rows, setRows] = useState<Row[] | null>(null);
  const [me, setMe] = useState("");
  const [msg, setMsg] = useState("");

  useEffect(() => {
    (async () => {
      const { data: { user } } = await sb.auth.getUser();
      if (!user) return;
      setMe(user.id);
      const mine = await sb.from("chat_members").select("chat_id").eq("user_id", user.id);
      const ids = ((mine.data ?? []) as { chat_id: string }[]).map((m) => m.chat_id);
      if (!ids.length) return setRows([]);
      const [chs, others] = await Promise.all([
        sb.from("chats").select("id,type,title,avatar_url").in("id", ids).neq("type", "channel"),
        sb.from("chat_members").select("chat_id,profiles(display_name,avatar_url)").in("chat_id", ids).neq("user_id", user.id),
      ]);
      const dm = new Map<string, { name: string; avatar: string | null }>();
      ((others.data ?? []) as unknown as Oth[]).forEach((o) => {
        if (!dm.has(o.chat_id)) dm.set(o.chat_id, { name: o.profiles?.display_name ?? "Пользователь", avatar: o.profiles?.avatar_url ?? null });
      });
      setRows(((chs.data ?? []) as Ch[]).map((c) => ({
        id: c.id,
        name: c.type === "group" ? c.title ?? "Группа" : dm.get(c.id)?.name ?? "Пользователь",
        avatar: c.type === "group" ? c.avatar_url : dm.get(c.id)?.avatar ?? null,
      })));
    })();
  }, []);

  async function send(r: Row) {
    setMsg("");
    const { error } = await sb.from("messages").insert({ chat_id: r.id, sender_id: me, body: text, fwd_from: from.slice(0, 100) });
    if (error) return setMsg(/rate limit/i.test(error.message) ? "Слишком часто, подождите несколько секунд" : "Не удалось переслать");
    setMsg("Переслано: " + r.name);
    setTimeout(onClose, 700);
  }

  return (
    <div className="fixed inset-0 z-40 flex animate-fade items-end bg-black/60 md:items-center md:justify-center" onClick={onClose}>
      <div className="max-h-[70%] w-full animate-page overflow-y-auto rounded-t-2xl bg-bg2 p-4 pb-safe md:max-w-sm md:rounded-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Переслать в…</h3>
          <button onClick={onClose} aria-label="Закрыть"><X size={22} /></button>
        </div>
        {msg && <p className="mt-2 text-sm text-green">{msg}</p>}
        {rows === null && <div className="skeleton mt-3 h-14 w-full" />}
        {rows && rows.length === 0 && <p className="mt-3 text-sm text-muted">Нет доступных чатов</p>}
        <ul className="mt-2 divide-y divide-line">
          {(rows ?? []).map((r) => (
            <li key={r.id}>
              <button onClick={() => send(r)} className="flex w-full items-center gap-3 py-2.5 text-left">
                <Avatar path={r.avatar} name={r.name} size={40} /><span className="truncate">{r.name}</span>
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
