"use client";
import { useEffect, useState } from "react";
import { Zap, Mic, Users, Palette } from "lucide-react";
import { VortexLogo } from "./Splash";

const REASONS = [
  "Сообщения приходят мгновенно, без обновления страницы",
  "Голосовые, фото и файлы в одном чате",
  "Истории, которые исчезают через 24 часа",
  "Группы и каналы со ссылками-приглашениями",
  "Свой цвет и стиль: приложение подстраивается под вас",
  "Тёмный минималистичный дизайн без лишнего шума",
];
const CHIPS = [
  { Icon: Zap, label: "Мгновенно" },
  { Icon: Mic, label: "Голосовые" },
  { Icon: Users, label: "Группы и каналы" },
  { Icon: Palette, label: "Ваш стиль" },
];

function useTypewriter(lines: string[]) {
  const [text, setText] = useState("");
  useEffect(() => {
    let i = 0, n = 0, del = false;
    let t: ReturnType<typeof setTimeout>;
    const tick = () => {
      const line = lines[i];
      if (!del) {
        n++; setText(line.slice(0, n));
        if (n === line.length) { del = true; t = setTimeout(tick, 1800); return; }
        t = setTimeout(tick, 38);
      } else {
        n--; setText(line.slice(0, n));
        if (n === 0) { del = false; i = (i + 1) % lines.length; t = setTimeout(tick, 350); return; }
        t = setTimeout(tick, 18);
      }
    };
    t = setTimeout(tick, 500);
    return () => clearTimeout(t);
  }, []);
  return text;
}

export default function AuthHero() {
  const text = useTypewriter(REASONS);
  return (
    <div className="relative overflow-hidden px-5 pb-4 pt-[calc(env(safe-area-inset-top)+28px)] md:flex md:min-h-dvh md:flex-col md:justify-center md:px-14">
      <div className="blob blob-a" />
      <div className="blob blob-b" />
      <div className="relative max-w-md">
        <VortexLogo className="vortex-spin h-14 w-14 md:h-20 md:w-20" />
        <h1 className="mt-3 text-4xl font-bold tracking-tight text-green md:mt-5 md:text-5xl">VORTEX</h1>
        <p className="mt-1 text-sm text-muted">Почему стоит выбрать нас</p>
        <p className="mt-3 min-h-[3.4rem] text-lg leading-snug md:min-h-[4.5rem] md:text-2xl">{text}<span className="caret" /></p>
        <div className="mt-6 hidden grid-cols-2 gap-3 md:grid">
          {CHIPS.map(({ Icon, label }, k) => (
            <div key={label} className="animate-page flex items-center gap-3 rounded-2xl border border-line bg-card/70 px-4 py-3 backdrop-blur" style={{ animationDelay: `${300 + k * 120}ms` }}>
              <Icon size={20} className="text-green" /><span className="text-sm">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
