"use client";
import { useEffect, useState } from "react";

export function VortexLogo({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" fill="none" stroke="rgb(var(--accent))" strokeLinecap="round" strokeWidth="4" className={className}>
      <path d="M32 6a26 26 0 1 1-26 26" />
      <path d="M32 16a16 16 0 1 1-16 16" opacity=".75" />
      <path d="M32 26a6 6 0 1 1-6 6" opacity=".5" />
    </svg>
  );
}

export default function Splash() {
  const [show, setShow] = useState(true);
  const [fade, setFade] = useState(false);
  useEffect(() => {
    if (sessionStorage.getItem("vx-splash")) { setShow(false); return; }
    sessionStorage.setItem("vx-splash", "1");
    const a = setTimeout(() => setFade(true), 900);
    const b = setTimeout(() => setShow(false), 1250);
    return () => { clearTimeout(a); clearTimeout(b); };
  }, []);
  if (!show) return null;
  return (
    <div className={`fixed inset-0 z-[100] grid place-items-center bg-bg transition-opacity duration-300 ${fade ? "opacity-0" : "opacity-100"}`}>
      <div className="flex flex-col items-center gap-4">
        <VortexLogo className="vortex-spin h-20 w-20" />
        <span className="animate-page text-2xl font-bold tracking-[0.3em] text-green">VORTEX</span>
      </div>
    </div>
  );
}
